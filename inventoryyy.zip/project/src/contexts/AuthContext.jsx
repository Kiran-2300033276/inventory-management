import { createContext, useState, useContext, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

// Create context
const AuthContext = createContext()

// Custom hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  // Check if user is logged in on initial load
  useEffect(() => {
    const user = localStorage.getItem('user')
    if (user) {
      setCurrentUser(JSON.parse(user))
    }
    setLoading(false)
  }, [])

  // Login function
  const login = (email, password) => {
    // This would be an API call in a real app
    return new Promise((resolve, reject) => {
      // Simulate API call with timeout
      setTimeout(() => {
        if (email === 'admin@example.com' && password === 'password') {
          const user = {
            id: 1,
            name: 'Admin User',
            email: email,
            role: 'admin',
            avatar: 'https://i.pravatar.cc/150?img=68'
          }
          setCurrentUser(user)
          localStorage.setItem('user', JSON.stringify(user))
          resolve(user)
        } else {
          reject(new Error('Invalid email or password'))
        }
      }, 1000)
    })
  }

  // Logout function
  const logout = () => {
    setCurrentUser(null)
    localStorage.removeItem('user')
    navigate('/login')
  }

  const value = {
    currentUser,
    login,
    logout
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}