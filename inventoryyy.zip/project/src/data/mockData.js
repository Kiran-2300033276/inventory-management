import { 
  HiOutlineCube, 
  HiOutlineShoppingCart, 
  HiOutlineUserAdd,
  HiOutlineExclamation
} from 'react-icons/hi'

// Dashboard data
export const getDashboardData = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        totalProducts: 115,
        totalValue: 145250,
        pendingOrders: 8,
        lowStockItems: [
          {
            id: '1',
            name: 'Laptop X1 Carbon',
            sku: 'LT-X1C-001',
            image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            currentStock: 5,
            reorderLevel: 10
          },
          {
            id: '4',
            name: 'Printer Ink Cartridge Black',
            sku: 'INK-BLK-004',
            image: 'https://images.pexels.com/photos/4792729/pexels-photo-4792729.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            currentStock: 2,
            reorderLevel: 15
          },
          {
            id: '6',
            name: 'Desk Lamp LED',
            sku: 'LMP-LED-006',
            image: 'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            currentStock: 0,
            reorderLevel: 8
          }
        ],
        inventoryChartData: {
          labels: ['Laptops', 'Monitors', 'Keyboards', 'Mice', 'Phones', 'Tablets'],
          datasets: [
            {
              label: 'Current Stock',
              data: [25, 32, 45, 78, 21, 15],
              backgroundColor: 'rgba(59, 130, 246, 0.5)',
              borderColor: 'rgba(59, 130, 246, 1)',
              borderWidth: 1
            },
            {
              label: 'Reorder Level',
              data: [10, 15, 20, 30, 10, 8],
              backgroundColor: 'rgba(239, 68, 68, 0.5)',
              borderColor: 'rgba(239, 68, 68, 1)',
              borderWidth: 1
            }
          ]
        },
        recentActivities: [
          {
            id: 1,
            title: 'New order created',
            time: '10 minutes ago',
            icon: HiOutlineShoppingCart,
            bgColor: 'bg-primary-50',
            iconColor: 'text-primary-500'
          },
          {
            id: 2,
            title: 'Stock level low for Laptop X1 Carbon',
            time: '1 hour ago',
            icon: HiOutlineExclamation,
            bgColor: 'bg-warning-50',
            iconColor: 'text-warning-500'
          },
          {
            id: 3,
            title: 'New supplier added: Quality Products Ltd.',
            time: '3 hours ago',
            icon: HiOutlineUserAdd,
            bgColor: 'bg-success-50',
            iconColor: 'text-success-500'
          },
          {
            id: 4,
            title: 'Inventory adjustment: USB-C Cable 2m (+25)',
            time: '5 hours ago',
            icon: HiOutlineCube,
            bgColor: 'bg-primary-50',
            iconColor: 'text-primary-500'
          }
        ]
      })
    }, 1000)
  })
}

// Products data
export const getProducts = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: '1',
          name: 'Laptop X1 Carbon',
          sku: 'LT-X1C-001',
          category: 'Electronics',
          description: 'Professional grade laptop with 16GB RAM, 512GB SSD, and Intel Core i7 processor.',
          price: 1299.99,
          cost: 899.99,
          stock: 5,
          reorderLevel: 10,
          image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          location: 'Warehouse A, Shelf A1-B3',
          createdAt: '2024-03-15T10:30:00.000Z'
        },
        {
          id: '2',
          name: 'Wireless Mouse M310',
          sku: 'MS-M310-002',
          category: 'Electronics',
          description: 'Ergonomic wireless mouse with long battery life and precise tracking.',
          price: 29.99,
          cost: 12.50,
          stock: 45,
          reorderLevel: 20,
          image: 'https://images.pexels.com/photos/399161/pexels-photo-399161.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          location: 'Warehouse A, Shelf A2-C5',
          createdAt: '2024-03-10T14:45:00.000Z'
        },
        {
          id: '3',
          name: 'Office Chair Ergonomic',
          sku: 'FR-OCE-003',
          category: 'Furniture',
          description: 'Adjustable office chair with lumbar support and breathable mesh back.',
          price: 199.99,
          cost: 89.99,
          stock: 12,
          reorderLevel: 5,
          image: 'https://images.pexels.com/photos/1957477/pexels-photo-1957477.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          location: 'Warehouse B, Section F12',
          createdAt: '2024-03-05T09:15:00.000Z'
        },
        {
          id: '4',
          name: 'Printer Ink Cartridge Black',
          sku: 'INK-BLK-004',
          category: 'Office Supplies',
          description: 'High-yield black ink cartridge compatible with most HP printers.',
          price: 24.99,
          cost: 8.75,
          stock: 2,
          reorderLevel: 15,
          image: 'https://images.pexels.com/photos/4792729/pexels-photo-4792729.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          location: 'Warehouse A, Shelf D8-E2',
          createdAt: '2024-02-28T11:20:00.000Z'
        },
        {
          id: '5',
          name: 'USB-C Cable 2m',
          sku: 'CBL-USC-005',
          category: 'Electronics',
          description: 'Durable USB-C to USB-C cable with fast charging and data transfer capabilities.',
          price: 14.99,
          cost: 3.25,
          stock: 78,
          reorderLevel: 30,
          image: 'https://images.pexels.com/photos/4219863/pexels-photo-4219863.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          location: 'Warehouse A, Shelf A3-B1',
          createdAt: '2024-02-20T16:10:00.000Z'
        },
        {
          id: '6',
          name: 'Desk Lamp LED',
          sku: 'LMP-LED-006',
          category: 'Office Supplies',
          description: 'Adjustable desk lamp with multiple brightness levels and color temperatures.',
          price: 39.99,
          cost: 15.50,
          stock: 0,
          reorderLevel: 8,
          image: 'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          location: 'Warehouse C, Section A5',
          createdAt: '2024-02-15T13:40:00.000Z'
        }
      ])
    }, 1000)
  })
}

// Get product by ID
export const getProductById = (id) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      getProducts().then(products => {
        const product = products.find(p => p.id === id)
        if (product) {
          resolve(product)
        } else {
          reject(new Error('Product not found'))
        }
      })
    }, 800)
  })
}