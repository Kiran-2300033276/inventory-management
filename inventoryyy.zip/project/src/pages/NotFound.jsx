import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { HiOutlineHome } from 'react-icons/hi'

const NotFound = () => {
  return (
    <div className="flex min-h-full flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <h1 className="text-9xl font-bold text-primary-500">404</h1>
        <h2 className="mt-2 text-3xl font-bold text-neutral-900">Page not found</h2>
        <p className="mt-4 text-base text-neutral-600">
          Sorry, we couldn't find the page you're looking for.
        </p>
      </motion.div>
      
      <div className="mt-10">
        <Link to="/dashboard" className="btn btn-primary flex items-center space-x-2">
          <HiOutlineHome className="h-5 w-5" />
          <span>Go back home</span>
        </Link>
      </div>
    </div>
  )
}

export default NotFound