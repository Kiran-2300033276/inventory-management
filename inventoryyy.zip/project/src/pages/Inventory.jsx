import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  HiOutlineSearch, 
  HiOutlineFilter,
  HiOutlineAdjustments,
  HiOutlineDownload,
  HiOutlineRefresh 
} from 'react-icons/hi'

const Inventory = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [selectedWarehouse, setSelectedWarehouse] = useState('all')

  const warehouses = [
    { id: 'all', name: 'All Warehouses' },
    { id: 'warehouse-a', name: 'Warehouse A' },
    { id: 'warehouse-b', name: 'Warehouse B' },
    { id: 'warehouse-c', name: 'Warehouse C' }
  ]

  const mockInventoryData = [
    {
      id: '1',
      name: 'Laptop X1 Carbon',
      sku: 'LT-X1C-001',
      location: 'Warehouse A, Shelf A1-B3',
      quantity: 5,
      reorderLevel: 10,
      status: 'low',
      lastUpdated: '2024-04-15',
      category: 'Electronics'
    },
    {
      id: '2',
      name: 'Wireless Mouse M310',
      sku: 'MS-M310-002',
      location: 'Warehouse A, Shelf A2-C5',
      quantity: 45,
      reorderLevel: 20,
      status: 'ok',
      lastUpdated: '2024-04-14',
      category: 'Electronics'
    },
    {
      id: '3',
      name: 'Office Chair Ergonomic',
      sku: 'FR-OCE-003',
      location: 'Warehouse B, Section F12',
      quantity: 12,
      reorderLevel: 5,
      status: 'ok',
      lastUpdated: '2024-04-10',
      category: 'Furniture'
    },
    {
      id: '4',
      name: 'Printer Ink Cartridge Black',
      sku: 'INK-BLK-004',
      location: 'Warehouse A, Shelf D8-E2',
      quantity: 2,
      reorderLevel: 15,
      status: 'low',
      lastUpdated: '2024-04-15',
      category: 'Office Supplies'
    },
    {
      id: '5',
      name: 'USB-C Cable 2m',
      sku: 'CBL-USC-005',
      location: 'Warehouse A, Shelf A3-B1',
      quantity: 78,
      reorderLevel: 30,
      status: 'ok',
      lastUpdated: '2024-04-12',
      category: 'Electronics'
    },
    {
      id: '6',
      name: 'Desk Lamp LED',
      sku: 'LMP-LED-006',
      location: 'Warehouse C, Section A5',
      quantity: 0,
      reorderLevel: 8,
      status: 'out',
      lastUpdated: '2024-04-08',
      category: 'Office Supplies'
    }
  ]

  const filteredInventory = mockInventoryData
    .filter(item => 
      (selectedWarehouse === 'all' || item.location.toLowerCase().includes(selectedWarehouse.replace('warehouse-', 'warehouse ').toLowerCase())) &&
      (item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
       item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
       item.category.toLowerCase().includes(searchQuery.toLowerCase()))
    )

  const getStatusBadge = (status) => {
    if (status === 'ok') {
      return <span className="inline-flex items-center rounded-full bg-success-50 px-2.5 py-0.5 text-xs font-medium text-success-700">In Stock</span>
    } else if (status === 'low') {
      return <span className="inline-flex items-center rounded-full bg-warning-50 px-2.5 py-0.5 text-xs font-medium text-warning-700">Low Stock</span>
    } else {
      return <span className="inline-flex items-center rounded-full bg-error-50 px-2.5 py-0.5 text-xs font-medium text-error-700">Out of Stock</span>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <h1 className="text-2xl font-semibold">Inventory</h1>
        <div className="flex space-x-2">
          <button className="btn btn-outline flex items-center space-x-2">
            <HiOutlineAdjustments className="h-5 w-5" />
            <span>Stock Adjustment</span>
          </button>
          <button className="btn btn-primary flex items-center space-x-2">
            <HiOutlineDownload className="h-5 w-5" />
            <span>Export</span>
          </button>
        </div>
      </div>
      
      <div className="card">
        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div className="w-full md:w-1/2 xl:w-1/3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <HiOutlineSearch className="h-5 w-5 text-neutral-400" />
              </div>
              <input
                type="text"
                className="form-input pl-10"
                placeholder="Search inventory..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="w-48">
              <select 
                className="form-input"
                value={selectedWarehouse}
                onChange={(e) => setSelectedWarehouse(e.target.value)}
              >
                {warehouses.map(warehouse => (
                  <option key={warehouse.id} value={warehouse.id}>
                    {warehouse.name}
                  </option>
                ))}
              </select>
            </div>
            
            <button 
              onClick={() => setShowFilters(!showFilters)} 
              className="btn btn-outline flex items-center space-x-2"
            >
              <HiOutlineFilter className="h-5 w-5" />
              <span>Filter</span>
            </button>
            
            <button className="btn btn-outline p-2">
              <HiOutlineRefresh className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {showFilters && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mt-4 pt-4 border-t border-neutral-200"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="form-label">Category</label>
                <select className="form-input">
                  <option value="">All Categories</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Office Supplies">Office Supplies</option>
                  <option value="Furniture">Furniture</option>
                </select>
              </div>
              
              <div>
                <label className="form-label">Stock Status</label>
                <select className="form-input">
                  <option value="">All</option>
                  <option value="ok">In Stock</option>
                  <option value="low">Low Stock</option>
                  <option value="out">Out of Stock</option>
                </select>
              </div>
              
              <div>
                <label className="form-label">Last Updated</label>
                <select className="form-input">
                  <option value="">Any time</option>
                  <option value="today">Today</option>
                  <option value="week">This Week</option>
                  <option value="month">This Month</option>
                </select>
              </div>
              
              <div className="flex items-end">
                <button className="btn btn-primary w-full">Apply Filters</button>
              </div>
            </div>
          </motion.div>
        )}
        
        <div className="mt-6 overflow-hidden rounded-lg border border-neutral-200">
          <table className="min-w-full divide-y divide-neutral-200">
            <thead className="bg-neutral-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Product
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Location
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Quantity
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Last Updated
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-neutral-200">
              {filteredInventory.map((item, index) => (
                <motion.tr 
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="hover:bg-neutral-50"
                >
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="ml-0">
                        <p className="text-sm font-medium text-neutral-900">{item.name}</p>
                        <p className="text-xs text-neutral-500">{item.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                    {item.location}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center space-x-1">
                      <span className="text-sm font-medium text-neutral-900">{item.quantity}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {getStatusBadge(item.status)}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                    {item.lastUpdated}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right">
                    <button className="text-primary-600 hover:text-primary-800 mr-2">
                      Adjust
                    </button>
                    <button className="text-primary-600 hover:text-primary-800">
                      Move
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            Showing {filteredInventory.length} of {mockInventoryData.length} items
          </p>
          
          <div className="flex items-center space-x-2">
            <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200 disabled:opacity-50 disabled:cursor-not-allowed">
              Previous
            </button>
            <button className="px-3 py-1 rounded-md bg-primary-600 text-white hover:bg-primary-700">
              1
            </button>
            <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Inventory