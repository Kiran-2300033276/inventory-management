import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { 
  HiOutlineArrowLeft, 
  HiOutlinePencil, 
  HiOutlineTrash,
  HiOutlineHome,
  HiOutlineChevronRight,
  HiOutlinePrinter
} from 'react-icons/hi'
import { motion } from 'framer-motion'
import { toast } from 'react-toastify'

// Mock data
import { getProductById } from '../data/mockData'

const ProductDetail = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [product, setProduct] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('details')

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const result = await getProductById(id)
        setProduct(result)
        setIsLoading(false)
      } catch (error) {
        console.error('Failed to fetch product:', error)
        setIsLoading(false)
        toast.error('Product not found')
        navigate('/products')
      }
    }

    fetchProduct()
  }, [id, navigate])

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="h-12 w-12 border-4 border-primary-200 border-t-primary-600 rounded-full"
        />
      </div>
    )
  }

  if (!product) {
    return (
      <div className="flex h-full items-center justify-center">
        <p className="text-neutral-500">Product not found.</p>
      </div>
    )
  }

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this product?')) {
      toast.success('Product deleted')
      navigate('/products')
    }
  }

  // Stock status
  const stockStatus = product.stock <= 0 
    ? { label: 'Out of Stock', color: 'error' }
    : product.stock < product.reorderLevel 
      ? { label: 'Low Stock', color: 'warning' }
      : { label: 'In Stock', color: 'success' }

  return (
    <div className="space-y-6">
      {/* Breadcrumbs */}
      <div className="flex items-center space-x-2 text-sm">
        <Link to="/dashboard" className="text-neutral-500 hover:text-primary-600">
          <HiOutlineHome className="h-4 w-4" />
        </Link>
        <HiOutlineChevronRight className="h-4 w-4 text-neutral-400" />
        <Link to="/products" className="text-neutral-500 hover:text-primary-600">
          Products
        </Link>
        <HiOutlineChevronRight className="h-4 w-4 text-neutral-400" />
        <span className="text-neutral-900 font-medium">{product.name}</span>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => navigate('/products')}
            className="rounded-md p-1.5 text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700"
          >
            <HiOutlineArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-2xl font-semibold">{product.name}</h1>
        </div>
        <div className="flex items-center space-x-2">
          <button className="btn btn-outline flex items-center space-x-2">
            <HiOutlinePrinter className="h-5 w-5" />
            <span>Print</span>
          </button>
          <button 
            onClick={() => navigate(`/products/edit/${id}`)}
            className="btn btn-outline flex items-center space-x-2"
          >
            <HiOutlinePencil className="h-5 w-5" />
            <span>Edit</span>
          </button>
          <button 
            onClick={handleDelete}
            className="btn btn-danger flex items-center space-x-2"
          >
            <HiOutlineTrash className="h-5 w-5" />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-neutral-200">
        <nav className="-mb-px flex space-x-6">
          {['details', 'stock', 'suppliers', 'history'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-3 px-1 text-sm font-medium border-b-2 ${
                activeTab === tab
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:border-neutral-300'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column - Image and basic info */}
        <div className="lg:col-span-1">
          <div className="card flex flex-col space-y-6">
            <div className="aspect-square w-full rounded-lg bg-neutral-100 overflow-hidden">
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center">
                  <span className="text-neutral-400">No image</span>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-sm text-neutral-500">SKU</p>
                <p className="font-medium">{product.sku}</p>
              </div>

              <div>
                <p className="text-sm text-neutral-500">Category</p>
                <p className="font-medium">{product.category}</p>
              </div>

              <div>
                <p className="text-sm text-neutral-500">Stock Status</p>
                <div className={`inline-flex items-center rounded-full bg-${stockStatus.color}-50 px-2.5 py-0.5 text-sm font-medium text-${stockStatus.color}-700`}>
                  {stockStatus.label}
                </div>
              </div>

              <div>
                <p className="text-sm text-neutral-500">Location</p>
                <p className="font-medium">{product.location || 'Not specified'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right column - Tab content details */}
        <div className="lg:col-span-2">
          {activeTab === 'details' && (
            <div className="card">
              <h2 className="text-lg font-medium mb-4">Product Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-4">
                <div>
                  <p className="text-sm text-neutral-500">Price</p>
                  <p className="text-xl font-medium">${product.price.toFixed(2)}</p>
                </div>
                
                <div>
                  <p className="text-sm text-neutral-500">Cost</p>
                  <p className="text-xl font-medium">${product.cost.toFixed(2)}</p>
                </div>
                
                <div>
                  <p className="text-sm text-neutral-500">Profit Margin</p>
                  <p className="text-xl font-medium">
                    {(((product.price - product.cost) / product.price) * 100).toFixed(2)}%
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-neutral-500">Created At</p>
                  <p className="font-medium">
                    {new Date(product.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              
              <div className="mt-8">
                <p className="text-sm text-neutral-500 mb-2">Description</p>
                <p className="text-neutral-700">
                  {product.description || 'No description provided'}
                </p>
              </div>
            </div>
          )}

          {activeTab === 'stock' && (
            <div className="space-y-6">
              <div className="card">
                <h2 className="text-lg font-medium mb-4">Stock Information</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-y-6 gap-x-4">
                  <div>
                    <p className="text-sm text-neutral-500">Current Stock</p>
                    <p className="text-xl font-medium">{product.stock}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-neutral-500">Reorder Level</p>
                    <p className="text-xl font-medium">{product.reorderLevel}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-neutral-500">Status</p>
                    <div className={`inline-flex items-center rounded-full bg-${stockStatus.color}-50 px-2.5 py-0.5 text-sm font-medium text-${stockStatus.color}-700`}>
                      {stockStatus.label}
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-base font-medium mb-2">Inventory Value</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <p className="text-sm text-neutral-500">At Cost</p>
                      <p className="text-xl font-medium">
                        ${(product.stock * product.cost).toFixed(2)}
                      </p>
                    </div>
                    
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <p className="text-sm text-neutral-500">At Retail</p>
                      <p className="text-xl font-medium">
                        ${(product.stock * product.price).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card">
                <h2 className="text-lg font-medium mb-4">Stock Movement</h2>
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead>
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Type
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Quantity
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Reference
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200">
                    <tr className="hover:bg-neutral-50">
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-700">
                        2024-04-15
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="inline-flex items-center rounded-full bg-success-50 px-2.5 py-0.5 text-xs font-medium text-success-700">
                          Stock In
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-700">
                        +25
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                        PO-12345
                      </td>
                    </tr>
                    <tr className="hover:bg-neutral-50">
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-700">
                        2024-04-10
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="inline-flex items-center rounded-full bg-error-50 px-2.5 py-0.5 text-xs font-medium text-error-700">
                          Stock Out
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-700">
                        -5
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                        ADJ-789
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'suppliers' && (
            <div className="card">
              <h2 className="text-lg font-medium mb-4">Suppliers</h2>
              
              <div className="overflow-hidden rounded-lg border border-neutral-200">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Supplier
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        SKU
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Unit Cost
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Lead Time
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    <tr className="hover:bg-neutral-50">
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="ml-3">
                            <p className="text-sm font-medium text-neutral-900">Tech Suppliers Inc.</p>
                            <p className="text-xs text-neutral-500">Primary</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                        TS-12345
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-800">
                        $49.99
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                        5-7 days
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500 text-right">
                        <button className="text-primary-600 hover:text-primary-800">
                          Order
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div className="mt-6">
                <button className="btn btn-outline w-full">
                  Add Supplier
                </button>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="card">
              <h2 className="text-lg font-medium mb-4">Product History</h2>
              
              <div className="space-y-6">
                <div className="border-l-2 border-primary-200 pl-4">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="text-base font-medium">Price Updated</h3>
                      <p className="text-sm text-neutral-500">Changed from $89.99 to $99.99</p>
                    </div>
                    <div className="text-sm text-neutral-500">
                      2024-04-12
                    </div>
                  </div>
                </div>
                
                <div className="border-l-2 border-primary-200 pl-4">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="text-base font-medium">Stock Adjusted</h3>
                      <p className="text-sm text-neutral-500">Added 25 units to inventory</p>
                    </div>
                    <div className="text-sm text-neutral-500">
                      2024-04-10
                    </div>
                  </div>
                </div>
                
                <div className="border-l-2 border-primary-200 pl-4">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="text-base font-medium">Product Created</h3>
                      <p className="text-sm text-neutral-500">Initial stock: 10 units</p>
                    </div>
                    <div className="text-sm text-neutral-500">
                      2024-04-01
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default ProductDetail