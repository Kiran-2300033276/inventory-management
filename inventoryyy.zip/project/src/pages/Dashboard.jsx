import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  HiOutlineCube, 
  HiOutlineCash, 
  HiOutlineShoppingCart,
  HiOutlineExclamation 
} from 'react-icons/hi'

// Components
import StatCard from '../components/dashboard/StatCard'
import InventoryChart from '../components/dashboard/InventoryChart'
import LowStockItems from '../components/dashboard/LowStockItems'
import RecentActivity from '../components/dashboard/RecentActivity'

// Mock data
import { getDashboardData } from '../data/mockData'

const Dashboard = () => {
  const [data, setData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate API call
    const fetchData = async () => {
      try {
        // In a real app, this would be an API call
        const result = await getDashboardData()
        setData(result)
        setIsLoading(false)
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error)
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="h-12 w-12 border-4 border-primary-200 border-t-primary-600 rounded-full"
        />
      </div>
    )
  }

  if (!data) {
    return (
      <div className="flex h-full items-center justify-center">
        <p className="text-neutral-500">Failed to load dashboard data.</p>
      </div>
    )
  }

  const stats = [
    {
      title: 'Total Products',
      value: data.totalProducts,
      icon: { component: HiOutlineCube },
      change: 4.75,
      status: 'primary'
    },
    {
      title: 'Total Value',
      value: `$${data.totalValue.toLocaleString()}`,
      icon: { component: HiOutlineCash },
      change: 11.4,
      status: 'success'
    },
    {
      title: 'Orders Pending',
      value: data.pendingOrders,
      icon: { component: HiOutlineShoppingCart },
      change: -2.7,
      status: 'primary'
    },
    {
      title: 'Low Stock Items',
      value: data.lowStockItems.length,
      icon: { component: HiOutlineExclamation },
      change: 8.2,
      status: 'warning'
    }
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <StatCard
              title={stat.title}
              value={stat.value}
              icon={stat.icon}
              change={stat.change}
              status={stat.status}
            />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-2"
        >
          <InventoryChart data={data.inventoryChartData} />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <RecentActivity activities={data.recentActivities} />
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <LowStockItems items={data.lowStockItems} />
      </motion.div>
    </div>
  )
}

export default Dashboard