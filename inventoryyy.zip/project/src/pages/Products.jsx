import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  HiOutlinePlus, 
  HiOutlineSearch,
  HiOutlineFilter,
  HiOutlineDownload,
  HiOutlineRefresh
} from 'react-icons/hi'

// Components
import ProductsTable from '../components/products/ProductsTable'
import ProductForm from '../components/products/ProductForm'
import { toast } from 'react-toastify'

// Mock data
import { getProducts } from '../data/mockData'

const Products = () => {
  const [products, setProducts] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts()
        setProducts(data)
        setIsLoading(false)
      } catch (error) {
        console.error('Failed to fetch products:', error)
        setIsLoading(false)
      }
    }

    fetchProducts()
  }, [])

  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleSubmit = (formData) => {
    if (editingProduct) {
      // Update existing product
      const updatedProducts = products.map(p => 
        p.id === editingProduct.id ? { ...p, ...formData } : p
      )
      setProducts(updatedProducts)
      toast.success('Product updated successfully')
    } else {
      // Add new product
      const newProduct = {
        id: Date.now().toString(),
        ...formData,
        createdAt: new Date().toISOString()
      }
      setProducts([...products, newProduct])
      toast.success('Product added successfully')
    }
    
    setShowForm(false)
    setEditingProduct(null)
  }

  const handleEdit = (product) => {
    setEditingProduct(product)
    setShowForm(true)
  }

  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this product?')) {
      setProducts(products.filter(p => p.id !== id))
      toast.success('Product deleted successfully')
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="h-12 w-12 border-4 border-primary-200 border-t-primary-600 rounded-full"
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {showForm ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="card"
        >
          <h2 className="text-xl font-medium mb-6">
            {editingProduct ? 'Edit Product' : 'Add New Product'}
          </h2>
          <ProductForm 
            product={editingProduct} 
            onSubmit={handleSubmit} 
            onCancel={() => {
              setShowForm(false)
              setEditingProduct(null)
            }}
          />
        </motion.div>
      ) : (
        <>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <h1 className="text-2xl font-semibold">Products</h1>
            <button 
              onClick={() => setShowForm(true)}
              className="btn btn-primary flex items-center space-x-2"
            >
              <HiOutlinePlus className="h-5 w-5" />
              <span>Add Product</span>
            </button>
          </div>
          
          <div className="card">
            <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
              <div className="w-full md:w-1/2 xl:w-1/3">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <HiOutlineSearch className="h-5 w-5 text-neutral-400" />
                  </div>
                  <input
                    type="text"
                    className="form-input pl-10"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => setShowFilters(!showFilters)} 
                  className="btn btn-outline flex items-center space-x-2"
                >
                  <HiOutlineFilter className="h-5 w-5" />
                  <span>Filter</span>
                </button>
                
                <button className="btn btn-outline flex items-center space-x-2">
                  <HiOutlineDownload className="h-5 w-5" />
                  <span>Export</span>
                </button>
                
                <button
                  onClick={() => {
                    setIsLoading(true)
                    setTimeout(() => {
                      setIsLoading(false)
                      toast.success('Products refreshed')
                    }, 1000)
                  }}
                  className="btn btn-outline flex items-center space-x-2"
                >
                  <HiOutlineRefresh className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            {showFilters && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="mt-4 pt-4 border-t border-neutral-200"
              >
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="form-label">Category</label>
                    <select className="form-input">
                      <option value="">All Categories</option>
                      <option value="Electronics">Electronics</option>
                      <option value="Clothing">Clothing</option>
                      <option value="Office Supplies">Office Supplies</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="form-label">Stock Status</label>
                    <select className="form-input">
                      <option value="">All</option>
                      <option value="in-stock">In Stock</option>
                      <option value="low-stock">Low Stock</option>
                      <option value="out-of-stock">Out of Stock</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="form-label">Price Range</label>
                    <div className="flex items-center space-x-2">
                      <input type="number" placeholder="Min" className="form-input" />
                      <span className="text-neutral-400">to</span>
                      <input type="number" placeholder="Max" className="form-input" />
                    </div>
                  </div>
                  
                  <div className="flex items-end">
                    <button className="btn btn-primary w-full">Apply Filters</button>
                  </div>
                </div>
              </motion.div>
            )}
            
            <div className="mt-6">
              <ProductsTable 
                products={filteredProducts} 
                onEdit={handleEdit} 
                onDelete={handleDelete} 
              />
              
              <div className="mt-4 flex items-center justify-between">
                <p className="text-sm text-neutral-500">
                  Showing {filteredProducts.length} of {products.length} products
                </p>
                
                <div className="flex items-center space-x-2">
                  <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200 disabled:opacity-50 disabled:cursor-not-allowed">
                    Previous
                  </button>
                  <button className="px-3 py-1 rounded-md bg-primary-600 text-white hover:bg-primary-700">
                    1
                  </button>
                  <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
                    2
                  </button>
                  <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
                    3
                  </button>
                  <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
                    Next
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default Products