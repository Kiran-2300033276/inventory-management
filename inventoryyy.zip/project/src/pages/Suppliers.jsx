import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  HiOutlinePlus,
  HiOutlineSearch,
  HiOutlineFilter,
  HiOutlinePhone,
  HiOutlineMail,
  HiOutlineLocationMarker,
  HiOutlineDownload
} from 'react-icons/hi'

const Suppliers = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [showAddForm, setShowAddForm] = useState(false)

  // Mock suppliers data
  const mockSuppliers = [
    {
      id: '1',
      name: 'Tech Suppliers Inc.',
      contactName: 'John Smith',
      email: 'john@techsuppliers.com',
      phone: '(555) 123-4567',
      address: '123 Tech Way, San Francisco, CA 94107',
      category: 'Electronics',
      status: 'active',
      lastOrder: '2024-04-15'
    },
    {
      id: '2',
      name: 'Office Essentials',
      contactName: 'Sarah Johnson',
      email: 'sarah@officeessentials.com',
      phone: '(555) 234-5678',
      address: '456 Office Street, New York, NY 10001',
      category: 'Office Supplies',
      status: 'active',
      lastOrder: '2024-04-10'
    },
    {
      id: '3',
      name: 'Furniture World',
      contactName: 'Mike Brown',
      email: 'mike@furnitureworld.com',
      phone: '(555) 345-6789',
      address: '789 Furniture Ave, Chicago, IL 60601',
      category: 'Furniture',
      status: 'inactive',
      lastOrder: '2024-03-22'
    },
    {
      id: '4',
      name: 'Global Distributors',
      contactName: 'Emily Chen',
      email: 'emily@globaldist.com',
      phone: '(555) 456-7890',
      address: '101 Global Place, Los Angeles, CA 90001',
      category: 'Electronics',
      status: 'active',
      lastOrder: '2024-04-08'
    }
  ]

  const filteredSuppliers = mockSuppliers.filter(supplier => 
    supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    supplier.contactName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    supplier.category.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <h1 className="text-2xl font-semibold">Suppliers</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="btn btn-primary flex items-center space-x-2"
          >
            <HiOutlinePlus className="h-5 w-5" />
            <span>Add Supplier</span>
          </button>
        </div>
      </div>

      {showAddForm ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="card"
        >
          <h2 className="text-xl font-medium mb-6">Add New Supplier</h2>
          
          <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="form-label">Supplier Name</label>
              <input
                id="name"
                type="text"
                className="form-input"
                placeholder="Enter supplier name"
              />
            </div>
            
            <div>
              <label htmlFor="contactName" className="form-label">Contact Person</label>
              <input
                id="contactName"
                type="text"
                className="form-input"
                placeholder="Enter contact name"
              />
            </div>
            
            <div>
              <label htmlFor="email" className="form-label">Email</label>
              <input
                id="email"
                type="email"
                className="form-input"
                placeholder="Enter email address"
              />
            </div>
            
            <div>
              <label htmlFor="phone" className="form-label">Phone</label>
              <input
                id="phone"
                type="tel"
                className="form-input"
                placeholder="Enter phone number"
              />
            </div>
            
            <div className="md:col-span-2">
              <label htmlFor="address" className="form-label">Address</label>
              <input
                id="address"
                type="text"
                className="form-input"
                placeholder="Enter full address"
              />
            </div>
            
            <div>
              <label htmlFor="category" className="form-label">Category</label>
              <select id="category" className="form-input">
                <option value="">Select Category</option>
                <option value="Electronics">Electronics</option>
                <option value="Office Supplies">Office Supplies</option>
                <option value="Furniture">Furniture</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="status" className="form-label">Status</label>
              <select id="status" className="form-input">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
            
            <div className="md:col-span-2 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="btn btn-outline"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
              >
                Save Supplier
              </button>
            </div>
          </form>
        </motion.div>
      ) : (
        <div className="card">
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
            <div className="w-full md:w-1/2 xl:w-1/3">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <HiOutlineSearch className="h-5 w-5 text-neutral-400" />
                </div>
                <input
                  type="text"
                  className="form-input pl-10"
                  placeholder="Search suppliers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setShowFilters(!showFilters)} 
                className="btn btn-outline flex items-center space-x-2"
              >
                <HiOutlineFilter className="h-5 w-5" />
                <span>Filter</span>
              </button>
              
              <button className="btn btn-outline flex items-center space-x-2">
                <HiOutlineDownload className="h-5 w-5" />
                <span>Export</span>
              </button>
            </div>
          </div>
          
          {showFilters && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 pt-4 border-t border-neutral-200"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="form-label">Category</label>
                  <select className="form-input">
                    <option value="">All Categories</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Office Supplies">Office Supplies</option>
                    <option value="Furniture">Furniture</option>
                  </select>
                </div>
                
                <div>
                  <label className="form-label">Status</label>
                  <select className="form-input">
                    <option value="">All</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                
                <div className="flex items-end">
                  <button className="btn btn-primary w-full">Apply Filters</button>
                </div>
              </div>
            </motion.div>
          )}
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSuppliers.map((supplier, index) => (
              <motion.div
                key={supplier.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="card p-5 flex flex-col h-full"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-medium text-neutral-900">{supplier.name}</h3>
                    <p className="text-sm text-neutral-500">{supplier.contactName}</p>
                  </div>
                  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    supplier.status === 'active' 
                      ? 'bg-success-50 text-success-700' 
                      : 'bg-neutral-100 text-neutral-800'
                  }`}>
                    {supplier.status === 'active' ? 'Active' : 'Inactive'}
                  </span>
                </div>
                
                <div className="space-y-3 flex-grow">
                  <div className="flex items-start space-x-3">
                    <HiOutlineMail className="h-5 w-5 text-neutral-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-neutral-700">{supplier.email}</span>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <HiOutlinePhone className="h-5 w-5 text-neutral-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-neutral-700">{supplier.phone}</span>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <HiOutlineLocationMarker className="h-5 w-5 text-neutral-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-neutral-700">{supplier.address}</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-neutral-200 flex justify-between items-center">
                  <div>
                    <p className="text-xs text-neutral-500">Last Order</p>
                    <p className="text-sm font-medium">{supplier.lastOrder}</p>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button className="btn btn-outline py-1 px-3 text-sm">
                      Edit
                    </button>
                    <button className="btn btn-primary py-1 px-3 text-sm">
                      Order
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default Suppliers