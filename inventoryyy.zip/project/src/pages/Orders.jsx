import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  HiOutlinePlus, 
  HiOutlineSearch,
  HiOutlineFilter,
  HiOutlineEye,
  HiOutlineDocumentDuplicate,
  HiOutlineTrash
} from 'react-icons/hi'

const Orders = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [selectedStatus, setSelectedStatus] = useState('all')

  // Mock orders data
  const mockOrders = [
    {
      id: 'PO-2024-001',
      supplier: 'Tech Suppliers Inc.',
      date: '2024-04-15',
      expectedDelivery: '2024-04-22',
      total: 5249.75,
      status: 'pending',
      items: 12
    },
    {
      id: 'PO-2024-002',
      supplier: 'Office Essentials',
      date: '2024-04-10',
      expectedDelivery: '2024-04-18',
      total: 1892.50,
      status: 'approved',
      items: 8
    },
    {
      id: 'PO-2024-003',
      supplier: 'Furniture World',
      date: '2024-04-05',
      expectedDelivery: '2024-04-25',
      total: 7450.00,
      status: 'delivered',
      items: 5
    },
    {
      id: 'PO-2024-004',
      supplier: 'Global Distributors',
      date: '2024-04-02',
      expectedDelivery: '2024-04-12',
      total: 3275.25,
      status: 'partial',
      items: 15
    },
    {
      id: 'PO-2024-005',
      supplier: 'Tech Suppliers Inc.',
      date: '2024-03-28',
      expectedDelivery: '2024-04-06',
      total: 4125.00,
      status: 'cancelled',
      items: 7
    }
  ]

  const filteredOrders = mockOrders.filter(order => 
    (selectedStatus === 'all' || order.status === selectedStatus) &&
    (order.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
     order.supplier.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return <span className="inline-flex items-center rounded-full bg-neutral-100 px-2.5 py-0.5 text-xs font-medium text-neutral-800">Pending</span>
      case 'approved':
        return <span className="inline-flex items-center rounded-full bg-primary-50 px-2.5 py-0.5 text-xs font-medium text-primary-700">Approved</span>
      case 'delivered':
        return <span className="inline-flex items-center rounded-full bg-success-50 px-2.5 py-0.5 text-xs font-medium text-success-700">Delivered</span>
      case 'partial':
        return <span className="inline-flex items-center rounded-full bg-warning-50 px-2.5 py-0.5 text-xs font-medium text-warning-700">Partial</span>
      case 'cancelled':
        return <span className="inline-flex items-center rounded-full bg-error-50 px-2.5 py-0.5 text-xs font-medium text-error-700">Cancelled</span>
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <h1 className="text-2xl font-semibold">Purchase Orders</h1>
        <button className="btn btn-primary flex items-center space-x-2">
          <HiOutlinePlus className="h-5 w-5" />
          <span>Create Order</span>
        </button>
      </div>
      
      <div className="card">
        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div className="w-full md:w-1/2 xl:w-1/3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <HiOutlineSearch className="h-5 w-5 text-neutral-400" />
              </div>
              <input
                type="text"
                className="form-input pl-10"
                placeholder="Search orders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <select 
              className="form-input"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="delivered">Delivered</option>
              <option value="partial">Partial</option>
              <option value="cancelled">Cancelled</option>
            </select>
            
            <button 
              onClick={() => setShowFilters(!showFilters)} 
              className="btn btn-outline flex items-center space-x-2"
            >
              <HiOutlineFilter className="h-5 w-5" />
              <span>Filter</span>
            </button>
          </div>
        </div>
        
        {showFilters && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mt-4 pt-4 border-t border-neutral-200"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="form-label">Supplier</label>
                <select className="form-input">
                  <option value="">All Suppliers</option>
                  <option value="Tech Suppliers Inc.">Tech Suppliers Inc.</option>
                  <option value="Office Essentials">Office Essentials</option>
                  <option value="Furniture World">Furniture World</option>
                  <option value="Global Distributors">Global Distributors</option>
                </select>
              </div>
              
              <div>
                <label className="form-label">Date Range</label>
                <div className="flex items-center space-x-2">
                  <input type="date" className="form-input" />
                  <span className="text-neutral-400">to</span>
                  <input type="date" className="form-input" />
                </div>
              </div>
              
              <div className="flex items-end">
                <button className="btn btn-primary w-full">Apply Filters</button>
              </div>
            </div>
          </motion.div>
        )}
        
        <div className="mt-6 overflow-hidden rounded-lg border border-neutral-200">
          <table className="min-w-full divide-y divide-neutral-200">
            <thead className="bg-neutral-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  PO Number
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Supplier
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Total
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-neutral-200">
              {filteredOrders.map((order, index) => (
                <motion.tr 
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="hover:bg-neutral-50"
                >
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="ml-0">
                        <p className="text-sm font-medium text-neutral-900">{order.id}</p>
                        <p className="text-xs text-neutral-500">{order.items} items</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-700">
                    {order.supplier}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="text-sm text-neutral-900">{order.date}</div>
                    <div className="text-xs text-neutral-500">Expected: {order.expectedDelivery}</div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-900">
                    ${order.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {getStatusBadge(order.status)}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right">
                    <div className="flex space-x-3 justify-end">
                      <button className="text-primary-600 hover:text-primary-800">
                        <HiOutlineEye className="h-5 w-5" />
                      </button>
                      <button className="text-primary-600 hover:text-primary-800">
                        <HiOutlineDocumentDuplicate className="h-5 w-5" />
                      </button>
                      <button className="text-error-600 hover:text-error-800">
                        <HiOutlineTrash className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-neutral-500">
            Showing {filteredOrders.length} of {mockOrders.length} orders
          </p>
          
          <div className="flex items-center space-x-2">
            <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200 disabled:opacity-50 disabled:cursor-not-allowed">
              Previous
            </button>
            <button className="px-3 py-1 rounded-md bg-primary-600 text-white hover:bg-primary-700">
              1
            </button>
            <button className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Orders