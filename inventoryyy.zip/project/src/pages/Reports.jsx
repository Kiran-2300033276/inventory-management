import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  HiOutlineDocumentReport, 
  HiOutlineDocumentDownload,
  HiOutlineChartBar,
  HiOutlineRefresh
} from 'react-icons/hi'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js'
import { Bar, Line, Pie } from 'react-chartjs-2'

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

const Reports = () => {
  const [timeRange, setTimeRange] = useState('month')
  
  // Mock data for charts
  const inventoryData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Stock Value ($)',
        data: [15000, 17200, 16800, 18500, 20100, 19500],
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 2
      }
    ]
  }
  
  const productCategoryData = {
    labels: ['Electronics', 'Office Supplies', 'Furniture', 'Kitchen', 'Books'],
    datasets: [
      {
        label: 'Product Count',
        data: [45, 32, 18, 12, 8],
        backgroundColor: [
          'rgba(59, 130, 246, 0.6)',
          'rgba(16, 185, 129, 0.6)',
          'rgba(245, 158, 11, 0.6)',
          'rgba(239, 68, 68, 0.6)',
          'rgba(168, 85, 247, 0.6)'
        ],
        borderColor: [
          'rgba(59, 130, 246, 1)',
          'rgba(16, 185, 129, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(168, 85, 247, 1)'
        ],
        borderWidth: 1
      }
    ]
  }
  
  const salesTrendData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Orders',
        data: [12, 15, 18, 14, 22, 19],
        borderColor: 'rgba(16, 185, 129, 1)',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  }
  
  // Chart options
  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          usePointStyle: true,
          boxWidth: 6,
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#111827',
        bodyColor: '#1F2937',
        borderColor: '#E5E7EB',
        borderWidth: 1,
        padding: 12,
        boxPadding: 6,
        usePointStyle: true
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          borderDash: [3, 3]
        },
        beginAtZero: true
      }
    }
  }
  
  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          boxWidth: 6,
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#111827',
        bodyColor: '#1F2937',
        borderColor: '#E5E7EB',
        borderWidth: 1,
        padding: 12,
        boxPadding: 6,
        usePointStyle: true
      }
    }
  }
  
  const lineOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          usePointStyle: true,
          boxWidth: 6,
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#111827',
        bodyColor: '#1F2937',
        borderColor: '#E5E7EB',
        borderWidth: 1,
        padding: 12,
        boxPadding: 6,
        usePointStyle: true
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          borderDash: [3, 3]
        },
        beginAtZero: true
      }
    }
  }
  
  // Report types
  const reportTypes = [
    {
      id: 'inventory-value',
      name: 'Inventory Value',
      description: 'Total value of inventory by product categories',
      icon: HiOutlineChartBar
    },
    {
      id: 'stock-levels',
      name: 'Stock Levels',
      description: 'Current stock levels for all products',
      icon: HiOutlineDocumentReport
    },
    {
      id: 'low-stock',
      name: 'Low Stock Items',
      description: 'Products with stock below reorder level',
      icon: HiOutlineDocumentReport
    },
    {
      id: 'supplier-performance',
      name: 'Supplier Performance',
      description: 'On-time delivery rate and quality ratings',
      icon: HiOutlineChartBar
    }
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <h1 className="text-2xl font-semibold">Reports & Analytics</h1>
        <div className="inline-flex rounded-md shadow-sm" role="group">
          <button 
            className={`px-4 py-2 text-sm font-medium ${timeRange === 'week' ? 'bg-primary-500 text-white' : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'} rounded-l-md`}
            onClick={() => setTimeRange('week')}
          >
            Week
          </button>
          <button 
            className={`px-4 py-2 text-sm font-medium ${timeRange === 'month' ? 'bg-primary-500 text-white' : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'}`}
            onClick={() => setTimeRange('month')}
          >
            Month
          </button>
          <button 
            className={`px-4 py-2 text-sm font-medium ${timeRange === 'year' ? 'bg-primary-500 text-white' : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'} rounded-r-md`}
            onClick={() => setTimeRange('year')}
          >
            Year
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Key metrics */}
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Total Products</h3>
            <HiOutlineRefresh className="h-5 w-5 text-neutral-400 cursor-pointer hover:text-primary-500" />
          </div>
          <div className="text-3xl font-semibold mt-2">115</div>
          <div className="text-sm text-success-600 mt-1">↑ 12% from last month</div>
        </div>
        
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Inventory Value</h3>
            <HiOutlineRefresh className="h-5 w-5 text-neutral-400 cursor-pointer hover:text-primary-500" />
          </div>
          <div className="text-3xl font-semibold mt-2">$145,250</div>
          <div className="text-sm text-success-600 mt-1">↑ 8.5% from last month</div>
        </div>
        
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Low Stock Items</h3>
            <HiOutlineRefresh className="h-5 w-5 text-neutral-400 cursor-pointer hover:text-primary-500" />
          </div>
          <div className="text-3xl font-semibold mt-2">12</div>
          <div className="text-sm text-error-600 mt-1">↑ 3 more than last month</div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Charts */}
        <div className="card h-80">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Inventory Value Trend</h3>
            <button className="text-sm text-primary-600 hover:text-primary-700 flex items-center space-x-1">
              <HiOutlineDocumentDownload className="h-4 w-4" />
              <span>Export</span>
            </button>
          </div>
          <div className="h-64">
            <Bar data={inventoryData} options={barOptions} />
          </div>
        </div>
        
        <div className="card h-80">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Product Categories</h3>
            <button className="text-sm text-primary-600 hover:text-primary-700 flex items-center space-x-1">
              <HiOutlineDocumentDownload className="h-4 w-4" />
              <span>Export</span>
            </button>
          </div>
          <div className="h-64">
            <Pie data={productCategoryData} options={pieOptions} />
          </div>
        </div>
        
        <div className="card h-80 lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Purchase Order Trend</h3>
            <button className="text-sm text-primary-600 hover:text-primary-700 flex items-center space-x-1">
              <HiOutlineDocumentDownload className="h-4 w-4" />
              <span>Export</span>
            </button>
          </div>
          <div className="h-64">
            <Line data={salesTrendData} options={lineOptions} />
          </div>
        </div>
      </div>
      
      <div className="card">
        <h2 className="text-xl font-medium mb-6">Available Reports</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reportTypes.map((report, index) => (
            <motion.div
              key={report.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="border border-neutral-200 rounded-lg p-4 hover:shadow-card-hover hover:border-primary-200 transition-all cursor-pointer"
            >
              <div className="flex items-center justify-center w-12 h-12 bg-primary-50 rounded-lg mb-4">
                <report.icon className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-lg font-medium mb-1">{report.name}</h3>
              <p className="text-sm text-neutral-500 mb-4">{report.description}</p>
              <button className="btn btn-outline w-full flex items-center justify-center space-x-2 py-1.5">
                <HiOutlineDocumentDownload className="h-5 w-5" />
                <span>Generate</span>
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Reports