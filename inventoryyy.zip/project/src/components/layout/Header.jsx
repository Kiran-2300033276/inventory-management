import { useState, useRef, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { 
  HiMenuAlt2, 
  HiOutlineBell, 
  HiOutlineSearch,
  HiOutlineCog
} from 'react-icons/hi'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '../../contexts/AuthContext'

const Header = ({ toggleSidebar, isSidebarOpen, isMobile }) => {
  const location = useLocation()
  const [title, setTitle] = useState('')
  const [isSearchFocused, setIsSearchFocused] = useState(false)
  const [notifications, setNotifications] = useState([
    { id: 1, text: 'Low stock: Laptop X1 Carbon (5 left)', read: false },
    { id: 2, text: 'Order #12345 from Supplier A has been delivered', read: false },
    { id: 3, text: 'New supplier registration: Tech Solutions Inc.', read: true }
  ])
  const [showNotifications, setShowNotifications] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const notificationRef = useRef(null)
  const userMenuRef = useRef(null)
  const { currentUser } = useAuth()

  const unreadCount = notifications.filter(n => !n.read).length

  useEffect(() => {
    // Set page title based on current path
    const path = location.pathname.split('/')[1]
    if (path) {
      setTitle(path.charAt(0).toUpperCase() + path.slice(1))
    } else {
      setTitle('Dashboard')
    }
  }, [location])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setShowNotifications(false)
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setShowUserMenu(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })))
  }

  return (
    <header className="bg-white border-b border-neutral-200 shadow-sm z-10">
      <div className="flex h-16 items-center justify-between px-4">
        <div className="flex items-center">
          {/* Hamburger menu for mobile */}
          {isMobile && (
            <button
              onClick={toggleSidebar}
              className="mr-4 rounded-md p-2 text-neutral-500 hover:bg-neutral-100 focus:outline-none"
            >
              <HiMenuAlt2 className="h-6 w-6" />
            </button>
          )}

          {/* Page title */}
          <h1 className="text-xl font-semibold text-neutral-800">{title}</h1>
        </div>

        <div className="flex items-center space-x-4">
          {/* Search Bar */}
          <div className="relative hidden md:block">
            <div className="flex items-center">
              <div className={`absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none transition-opacity ${isSearchFocused ? 'opacity-100' : 'opacity-70'}`}>
                <HiOutlineSearch className="h-5 w-5 text-neutral-500" />
              </div>
              <input
                type="text"
                placeholder="Search..."
                className={`py-2 pl-10 pr-4 rounded-lg border ${isSearchFocused ? 'border-primary-500 ring-2 ring-primary-100' : 'border-neutral-300'} focus:outline-none transition-all w-64`}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
              />
            </div>
          </div>

          {/* Notifications */}
          <div className="relative" ref={notificationRef}>
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative rounded-full p-1 text-neutral-600 hover:bg-neutral-100 focus:outline-none"
            >
              <HiOutlineBell className="h-6 w-6" />
              {unreadCount > 0 && (
                <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-error-500 ring-2 ring-white" />
              )}
            </button>

            <AnimatePresence>
              {showNotifications && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute right-0 mt-2 w-80 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 z-50"
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-medium text-neutral-700">Notifications</h3>
                      {unreadCount > 0 && (
                        <button
                          onClick={markAllAsRead}
                          className="text-xs text-primary-600 hover:text-primary-800"
                        >
                          Mark all as read
                        </button>
                      )}
                    </div>
                    <div className="divide-y divide-neutral-100 max-h-96 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <p className="py-4 text-center text-sm text-neutral-500">
                          No notifications
                        </p>
                      ) : (
                        notifications.map((notification) => (
                          <div
                            key={notification.id}
                            className={`py-3 ${notification.read ? 'opacity-70' : 'bg-primary-50'}`}
                          >
                            <p className="text-sm text-neutral-700">{notification.text}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Settings */}
          <button className="rounded-full p-1 text-neutral-600 hover:bg-neutral-100 focus:outline-none">
            <HiOutlineCog className="h-6 w-6" />
          </button>

          {/* User menu */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2 rounded-full focus:outline-none"
            >
              <img
                src={currentUser.avatar}
                alt="User Avatar"
                className="h-8 w-8 rounded-full border border-neutral-200"
              />
            </button>

            <AnimatePresence>
              {showUserMenu && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute right-0 mt-2 w-48 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 z-50"
                >
                  <div className="py-1">
                    <a
                      href="#profile"
                      className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                    >
                      Profile
                    </a>
                    <a
                      href="#settings"
                      className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                    >
                      Settings
                    </a>
                    <button
                      onClick={() => {}}
                      className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                    >
                      Logout
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header