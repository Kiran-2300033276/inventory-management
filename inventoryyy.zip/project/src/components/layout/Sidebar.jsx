import { NavLink } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  HiOutlineHome, 
  HiOutlineDatabase,
  HiOutlineShoppingCart, 
  HiOutlineUsers, 
  HiOutlineDocumentReport,
  HiOutlineShoppingBag,
  HiOutlineX
} from 'react-icons/hi'
import { useAuth } from '../../contexts/AuthContext'

const Sidebar = ({ isOpen, toggleSidebar, isMobile }) => {
  const { currentUser, logout } = useAuth()

  const navItems = [
    { path: '/dashboard', name: 'Dashboard', icon: HiOutlineHome },
    { path: '/products', name: 'Products', icon: HiOutlineShoppingCart },
    { path: '/inventory', name: 'Inventory', icon: HiOutlineDatabase },
    { path: '/suppliers', name: 'Suppliers', icon: HiOutlineUsers },
    { path: '/orders', name: 'Purchase Orders', icon: HiOutlineShoppingBag },
    { path: '/reports', name: 'Reports', icon: HiOutlineDocumentReport },
  ]

  return (
    <>
      {/* Mobile overlay */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity" 
          onClick={toggleSidebar}
        />
      )}

      <AnimatePresence>
        {isOpen && (
          <motion.aside
            initial={isMobile ? { x: -280 } : { x: 0 }}
            animate={{ x: 0 }}
            exit={isMobile ? { x: -280 } : { x: 0 }}
            transition={{ duration: 0.2 }}
            className={`z-30 flex h-full w-64 flex-col bg-white shadow-lg ${isMobile ? 'fixed' : 'relative'}`}
          >
            {/* Logo */}
            <div className="flex items-center justify-between p-4 border-b border-neutral-200">
              <h1 className="text-xl font-bold text-primary-600">
                InvenTrack
              </h1>
              {isMobile && (
                <button onClick={toggleSidebar} className="p-1 rounded-md hover:bg-neutral-100">
                  <HiOutlineX className="h-6 w-6 text-neutral-500" />
                </button>
              )}
            </div>

            {/* User Profile */}
            <div className="flex items-center space-x-3 p-4 border-b border-neutral-200">
              <img 
                src={currentUser.avatar} 
                alt="User Avatar" 
                className="h-10 w-10 rounded-full"
              />
              <div>
                <p className="font-medium text-neutral-800">{currentUser.name}</p>
                <p className="text-xs text-neutral-500">{currentUser.role}</p>
              </div>
            </div>

            {/* Navigation Links */}
            <nav className="flex-1 overflow-y-auto p-2">
              <ul className="space-y-1">
                {navItems.map((item) => (
                  <li key={item.path}>
                    <NavLink
                      to={item.path}
                      className={({ isActive }) => 
                        `flex items-center space-x-3 rounded-md px-3 py-2 transition-colors ${
                          isActive 
                            ? 'bg-primary-50 text-primary-700' 
                            : 'text-neutral-700 hover:bg-neutral-100'
                        }`
                      }
                    >
                      <item.icon className="h-5 w-5" />
                      <span>{item.name}</span>
                    </NavLink>
                  </li>
                ))}
              </ul>
            </nav>

            {/* Footer */}
            <div className="p-4 border-t border-neutral-200">
              <button 
                onClick={logout}
                className="flex w-full items-center justify-center rounded-md bg-neutral-100 px-4 py-2 text-neutral-700 hover:bg-neutral-200 transition-colors"
              >
                Logout
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  )
}

export default Sidebar