import { motion } from 'framer-motion'

const StatCard = ({ title, value, icon, change, status }) => {
  let changeColor = 'text-neutral-500'
  let bgColor = 'bg-primary-50'
  let iconColor = 'text-primary-500'
  
  if (status === 'success') {
    bgColor = 'bg-success-50'
    iconColor = 'text-success-500'
  } else if (status === 'warning') {
    bgColor = 'bg-warning-50'
    iconColor = 'text-warning-500'
  } else if (status === 'error') {
    bgColor = 'bg-error-50'
    iconColor = 'text-error-500'
  }
  
  if (change > 0) {
    changeColor = 'text-success-500'
  } else if (change < 0) {
    changeColor = 'text-error-500'
  }

  return (
    <motion.div 
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
      className="card"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-neutral-500">{title}</p>
          <h3 className="mt-1 text-2xl font-semibold text-neutral-900">{value}</h3>
        </div>
        <div className={`rounded-full p-3 ${bgColor}`}>
          {icon && <icon.component className={`h-6 w-6 ${iconColor}`} />}
        </div>
      </div>
      <div className="mt-4">
        <span className={`text-sm ${changeColor}`}>
          {change > 0 ? '↑' : change < 0 ? '↓' : ''}
          {Math.abs(change)}% 
        </span>
        <span className="text-sm text-neutral-500 ml-1">from last month</span>
      </div>
    </motion.div>
  )
}

export default StatCard