import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend 
} from 'chart.js'
import { Bar } from 'react-chartjs-2'

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const InventoryChart = ({ data }) => {
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          usePointStyle: true,
          boxWidth: 6,
          font: {
            size: 12
          }
        }
      },
      title: {
        display: false
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#111827',
        bodyColor: '#1F2937',
        borderColor: '#E5E7EB',
        borderWidth: 1,
        padding: 12,
        boxPadding: 6,
        usePointStyle: true
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          borderDash: [3, 3]
        },
        beginAtZero: true,
        ticks: {
          precision: 0
        }
      }
    }
  }

  return (
    <div className="card h-80">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium">Inventory Levels</h3>
        <div className="inline-flex rounded-md shadow-sm" role="group">
          <button className="px-3 py-1 text-xs font-medium bg-primary-500 text-white rounded-l-md">
            Week
          </button>
          <button className="px-3 py-1 text-xs font-medium bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
            Month
          </button>
          <button className="px-3 py-1 text-xs font-medium bg-neutral-100 text-neutral-700 hover:bg-neutral-200 rounded-r-md">
            Year
          </button>
        </div>
      </div>
      <div className="h-64">
        <Bar options={options} data={data} />
      </div>
    </div>
  )
}

export default InventoryChart