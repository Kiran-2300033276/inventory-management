import { motion } from 'framer-motion'

const RecentActivity = ({ activities }) => {
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium">Recent Activity</h3>
        <button className="text-sm text-primary-600 hover:text-primary-700">
          View All
        </button>
      </div>
      <div className="space-y-4">
        {activities.map((activity, index) => (
          <motion.div 
            key={activity.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start space-x-3"
          >
            <div className={`mt-1 flex-shrink-0 rounded-full p-2 ${activity.bgColor}`}>
              <activity.icon className={`h-4 w-4 ${activity.iconColor}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-neutral-800">{activity.title}</p>
              <p className="text-xs text-neutral-500">{activity.time}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default RecentActivity