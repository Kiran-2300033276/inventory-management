import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  HiOutlinePencil, 
  HiOutlineTrash, 
  HiOutlineEye,
  HiOutlineChevronUp,
  HiOutlineChevronDown
} from 'react-icons/hi'

const ProductsTable = ({ products, onDelete, onEdit }) => {
  const [sortField, setSortField] = useState('name')
  const [sortDirection, setSortDirection] = useState('asc')
  const [selectedProducts, setSelectedProducts] = useState([])
  
  const toggleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('asc')
    }
  }
  
  const getSortIcon = (field) => {
    if (sortField !== field) return null
    
    return sortDirection === 'asc' 
      ? <HiOutlineChevronUp className="h-4 w-4" />
      : <HiOutlineChevronDown className="h-4 w-4" />
  }
  
  const sortedProducts = [...products].sort((a, b) => {
    if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1
    if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1
    return 0
  })

  const toggleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedProducts(products.map(p => p.id))
    } else {
      setSelectedProducts([])
    }
  }

  const toggleSelectProduct = (id) => {
    if (selectedProducts.includes(id)) {
      setSelectedProducts(selectedProducts.filter(pid => pid !== id))
    } else {
      setSelectedProducts([...selectedProducts, id])
    }
  }
  
  return (
    <div className="overflow-hidden rounded-lg border border-neutral-200">
      {selectedProducts.length > 0 && (
        <div className="bg-primary-50 p-4 border-b border-neutral-200">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-neutral-700">
              {selectedProducts.length} item{selectedProducts.length !== 1 && 's'} selected
            </span>
            <div className="space-x-2">
              <button className="btn btn-outline py-1 px-3 text-sm">
                Export
              </button>
              <button 
                className="btn btn-danger py-1 px-3 text-sm"
                onClick={() => {
                  // Handle batch delete
                  alert(`Delete ${selectedProducts.length} items?`)
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
      
      <table className="min-w-full divide-y divide-neutral-200">
        <thead className="bg-neutral-50">
          <tr>
            <th className="w-12 px-4 py-3">
              <input 
                type="checkbox" 
                className="rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                onChange={toggleSelectAll}
                checked={selectedProducts.length === products.length && products.length > 0}
              />
            </th>
            <th 
              className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider cursor-pointer"
              onClick={() => toggleSort('name')}
            >
              <div className="flex items-center space-x-1">
                <span>Product Name</span>
                {getSortIcon('name')}
              </div>
            </th>
            <th 
              className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider cursor-pointer"
              onClick={() => toggleSort('sku')}
            >
              <div className="flex items-center space-x-1">
                <span>SKU</span>
                {getSortIcon('sku')}
              </div>
            </th>
            <th 
              className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider cursor-pointer"
              onClick={() => toggleSort('category')}
            >
              <div className="flex items-center space-x-1">
                <span>Category</span>
                {getSortIcon('category')}
              </div>
            </th>
            <th 
              className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider cursor-pointer"
              onClick={() => toggleSort('price')}
            >
              <div className="flex items-center space-x-1">
                <span>Price</span>
                {getSortIcon('price')}
              </div>
            </th>
            <th 
              className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider cursor-pointer"
              onClick={() => toggleSort('stock')}
            >
              <div className="flex items-center space-x-1">
                <span>Stock</span>
                {getSortIcon('stock')}
              </div>
            </th>
            <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-neutral-200">
          {sortedProducts.map((product, index) => (
            <motion.tr 
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="hover:bg-neutral-50"
            >
              <td className="px-4 py-3 whitespace-nowrap">
                <input 
                  type="checkbox" 
                  className="rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                  checked={selectedProducts.includes(product.id)}
                  onChange={() => toggleSelectProduct(product.id)}
                />
              </td>
              <td className="px-4 py-3 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 flex-shrink-0 rounded bg-neutral-200">
                    {product.image && (
                      <img
                        src={product.image}
                        alt={product.name}
                        className="h-10 w-10 rounded object-cover"
                      />
                    )}
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-neutral-900">{product.name}</p>
                  </div>
                </div>
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500">
                {product.sku}
              </td>
              <td className="px-4 py-3 whitespace-nowrap">
                <span className="inline-flex items-center rounded-full bg-neutral-100 px-2.5 py-0.5 text-xs font-medium text-neutral-800">
                  {product.category}
                </span>
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-800">
                ${product.price.toFixed(2)}
              </td>
              <td className="px-4 py-3 whitespace-nowrap">
                {product.stock < product.reorderLevel ? (
                  <span className="inline-flex items-center rounded-full bg-error-50 px-2.5 py-0.5 text-xs font-medium text-error-700">
                    {product.stock}
                  </span>
                ) : (
                  <span className="inline-flex items-center rounded-full bg-success-50 px-2.5 py-0.5 text-xs font-medium text-success-700">
                    {product.stock}
                  </span>
                )}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500 text-right">
                <div className="flex space-x-2 justify-end">
                  <Link to={`/products/${product.id}`} className="text-primary-600 hover:text-primary-800">
                    <HiOutlineEye className="h-5 w-5" />
                  </Link>
                  <button onClick={() => onEdit(product)} className="text-warning-600 hover:text-warning-800">
                    <HiOutlinePencil className="h-5 w-5" />
                  </button>
                  <button onClick={() => onDelete(product.id)} className="text-error-600 hover:text-error-800">
                    <HiOutlineTrash className="h-5 w-5" />
                  </button>
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default ProductsTable